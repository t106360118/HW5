package pa;

public class CardException extends Exception {

}
