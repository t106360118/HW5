package pa;

public class test_p45 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Car44 car1 = new Car44("1̖܇");
		car1.start();
		
		Car44 car2 = new Car44("2̖܇");
		car2.start();
		for(int i=0;i<5;i++)
		{
			System.out.println("�����M��main()��̎������");
		}
	}

}
