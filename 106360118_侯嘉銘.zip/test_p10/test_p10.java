package pa;

public class test_p10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		pc.Car car1=new pc.Car();
		car1.show();
}
}
